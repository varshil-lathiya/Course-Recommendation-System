import pandas as pd
import numpy as np
import neattext.functions as nfx
import seaborn as sn

from sklearn.feature_extraction.text import TfidfVectorizer,CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity,linear_kernel

df = pd.read_csv('C:/Users/HP/Desktop/Django Projects/Course/Courserecommend/ml_models/udemy_course_data.csv')
df.head()

# list all the methods present in the neattext function

dir(nfx)

df['course_title'].iloc[1:5]

# generating clean text by removing the stopwords and special characters


df['Clean_title'] = df['course_title'].apply(nfx.remove_stopwords)

df['Clean_title'] = df['Clean_title'].apply(nfx.remove_special_characters)

df['Clean_title'].iloc[1:5]

# vectorizing the course_title

countvect = CountVectorizer()

cv_mat = countvect.fit_transform(df['Clean_title'])

cv_mat

cv_mat.todense()

# df_cv_words = pd.DataFrame(cv_mat.todense(),columns=countvect.get_feature_names())
df_cv_words = pd.DataFrame(cv_mat.todense(), columns=countvect.get_feature_names_out())
df_cv_words

# cosine similarity matrix

cosine_sim_mat = cosine_similarity(cv_mat)

cosine_sim_mat

# drop duplicates 

course_index = pd.Series(df.index,index = df['course_title']).drop_duplicates()

course_index

course_dict = dict(course_index)


course_keys = list(course_dict.keys())

touse = {}
counter = 0
keyword = 'Java'
for key,value in course_dict.items():
    if keyword in key:
        touse[counter] = key
        
    counter+=1
    
touse

temp = df[df['course_title'].str.contains('Python')]
temp.head()

top6 = temp.sort_values(by = 'num_subscribers',ascending=False).head(6)

top6

index = course_index['How To Maximize Your Profits Trading Options']

scores = list(enumerate(cosine_sim_mat[index]))
scores

sorted_score = sorted(scores,key = lambda x:x[1],reverse=True)
sorted_score

# so the sorted score list is a collection of tuples 
# which have the index and the value,so i will select the indices first

sorted_indices = [i[0] for i in sorted_score[1:]]

sorted_values = [i[1] for i in sorted_score[1:]]

sorted_values

recommended_result_df = df.iloc[sorted_indices]

recommended_result_df

recommended_result_df['Similarity_Score'] = np.array(sorted_values)

recommended_result_df

use_df = recommended_result_df[['Clean_title','Similarity_Score']]
use_df
                                

def recommend_course(title,numrec = 10):
    
    course_index = pd.Series(
        df.index, index=df['course_title']).drop_duplicates()

    index = course_index[title]

    scores = list(enumerate(cosine_sim_mat [index]))

    sorted_scores = sorted(scores, key=lambda x: x[1], reverse=True)

    selected_course_index = [i[0] for i in sorted_scores[1:]]

    selected_course_score = [i[1] for i in sorted_scores[1:]]

    rec_df = df.iloc[selected_course_index]

    rec_df['Similarity_Score'] = selected_course_score

    final_recommended_courses = rec_df[[
        'course_title', 'Similarity_Score', 'url', 'price', 'num_subscribers']]

    return final_recommended_courses.head(numrec)

ans = recommend_course('Trading Options Basics',20)
ans
ans.shape
ans.columns
df.head()
df.to_csv('UdemyCleanedTitle.csv',index = None)


import joblib  # For saving and loading models

# Save the trained CountVectorizer
joblib.dump(countvect, "count_vectorizer.pkl")
# Save the cosine similarity matrix
joblib.dump(cosine_sim_mat, "cosine_similarity.pkl")
# Save the DataFrame with course details (optional but useful)
df.to_csv("cleaned_courses.csv", index=False)
print("Model saved successfully!")
